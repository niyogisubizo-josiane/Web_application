
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginForm from './LoginForm';
import Insert from './Insert';
import FetcheData from './FetcheData';
import AddUser from './AddUser';
import './App.css'
function App() {
    return (
      <Router>
        <Routes>
          <Route path="/" element={<LoginForm />} />
          <Route path="/Insert" element={<Insert />} />
          <Route path="/FetcheData" element={< FetcheData/>} />
          <Route path="/AddUser" element={<AddUser />} />
        </Routes>
      </Router>
    );
  }
  
  export default App;