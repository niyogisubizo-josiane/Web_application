import React from 'react'
  import axios from 'axios'
  import { useState} from 'react'
  export default function AddUser() {
    const [formData,setformData]=useState({
    username:'',
     password:'' 
    })
    const submit=(e)=>{
      e.preventDefault()
      axios.post('http://localhost:4000/user',formData)
      .then(resp=>{
        console.log(resp)
        alert(resp.data.message)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    return (
      <div>
        <nav className='nav'>
        <a href="/LoginForm">Login</a></nav>
       <div className='bg-slate-500'>
          <center>
    
            <form action="" method="post">
            <h1>Add your username and password please</h1>
  
            <input type="text" value={formData.username} name='username' onChange={e=>setformData({...formData,username:e.target.value})} placeholder='enter username'/><br />
  
  
            <input type="password" value={formData.password} name='password' onChange={e=>setformData({...formData,password:e.target.value})} placeholder='enter passsord'/><br />
            <button onClick={submit}>add</button>
          </form></center></div></div>
          ) } 