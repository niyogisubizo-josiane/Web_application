import React from 'react'
  import axios from 'axios'
  import { useState} from 'react'
  export default function Insert() {
    const [formData,setformData]=useState({
     name:'',
     location:'' 
    })
    const submit=(e)=>{
      e.preventDefault()
      axios.post('http://localhost:4000/insert',formData)
      .then(resp=>{
        console.log(resp)
        alert(resp.data.message)
      })
      .catch(err=>{
        console.log(err)
      })
    }
    return (
      <div>
        <nav className='nav'>
        <a href="/Insert">insert customer</a>
        <a href="/FetcheData">Fetche customer</a></nav>
       <div className='bg-slate-500'>
          <center>
    
            <form action="" method="post">
            <h1>Register here</h1>
  
            <input type="text" value={formData.name} name='name' onChange={e=>setformData({...formData,name:e.target.value})} placeholder='enter your name'/><br />
  
  
            <input type="text" value={formData.location} name='location' onChange={e=>setformData({...formData,location:e.target.value})} placeholder='enter location'/><br />
            <button onClick={submit}>submit</button>
          </form></center></div></div>
          ) }