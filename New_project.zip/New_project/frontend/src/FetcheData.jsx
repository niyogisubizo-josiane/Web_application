/* import React from 'react'
import Testprops from './components/Testprops'
import DynamicList from './components/DynamicList'
import Hooks from './components/Hooks'
export default function App() {
  return (
    <div>
      <Testprops name='Byamukama' age={50} fruits = {['orange','banana','apple']}/>

      <DynamicList/>
      <Hooks/>
    </div>
  )
} */
  import React from 'react';
  import axios from 'axios'
  import { useState,useEffect } from 'react'
  export default function App() {
    //set update form state
    const [formUpdate,setformUpdate]=useState({
      name:'',
      location:'' 
     })
    const [customer,setCustomer]=useState([]) 

    //set effect on forms
    const [openEdit, setOpenEdit]=useState(false)
//view code starts here
useEffect(()=>{
  axios.get('http://localhost:4000/view')
  .then(resp=>{
    console.log(resp)
    setCustomer(resp.data.result)
  })
  .catch(err=>console.log())
},[customer])

//delete code starts here
const handleDelete=(id)=>{
  axios.delete(`http://localhost:4000/delete/${id}`)
  .then(resp=>{
    console.log(resp)
    setCustomer(customer.filter(customer=> customer.id != id))
    alert('customer deleted')
  })
  .catch(err=>{
    console.log(err)
    alert('Fialed to delete customer')
  })
}

//handle upate form open and close when user clicks on update button
const handleUpdate=(id)=>{
  axios.get(`http://localhost:4000/customer/${id}`)
  .then(resp=>{
      console.log(resp)
      setformUpdate(resp.data.result)
      setOpenEdit(true)
  })
  .catch(err=>{
    console.log(err)
    alert('failed to fetch user by ID')
  })
}

//update codes here 
const handleEdit=(id)=>{
  axios.put(`http://localhost:4000/update/${id}`, formUpdate)
  .then(resp=>{
    console.log(resp)
    alert('Customer Updated well')
    setOpenEdit(false)
  })
  .catch(err=>{
    console.log(err)
    alert('Customer Failed to be Updated!')
  })
}

const handleUpdates=(id)=>{
  setOpenEdit(true)
  axios.get(`http://localhost:4000/customer/${id}`)
  .then(resp=>{
    console.log(resp)
    setformUpdate(resp.data.result)
  })
  .catch(err=>console.log(err))
}
const handleForm=(e)=>{
  e.preventDefault()
}
  return (
      
      <div>
        <div>
        <center>

        { openEdit && (
          <form onSubmit={handleForm} action="" method="post">
          <h1>Update form</h1>

          <input type="text" value={formUpdate.name} name='name' onChange={e=>setformUpdate({...formUpdate,name:e.target.value})} placeholder='enter username'/><br />


          <input type="text" value={formUpdate.location} name='location' onChange={e=>setformUpdate({...formUpdate,location:e.target.value})} placeholder='enter location'/><br />
          <button onClick={e=>handleEdit(formUpdate.id)}>Update</button>
        </form>
        )}
        </center>
        </div>
      <div>
        <center>
        <table border="2">
       <tr>
        <th>Id</th>
        <th>names</th>
        <th>location</th>
        <th>modify</th>
       </tr>
       {
        customer.map(data=>(
          <tr>
          <td>{data.id}</td>
          <td>{data.name}</td>
          <td>{data.location}</td>
          <td>
            <button onClick={e=>handleUpdates(data.id)}>Update</button>
            <button onClick={e=>handleDelete(data.id)}>Delete</button>
          </td>
          </tr>
        ))
       }
        </table>
        </center>
      </div>
      </div>
    )
  }
  
