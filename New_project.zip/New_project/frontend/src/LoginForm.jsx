
import { useNavigate } from 'react-router-dom'; // 👈 import useNavigate
import React, { useState } from 'react';
import axios from 'axios';
function LoginForm() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate(); // 👈 initialize useNavigate

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
     const response = await axios.post('http://localhost:4000/login', {username, password });
            if (response.data.success=== true){
                navigate('/insert');
            }else{
                 setMessage(response.data.message);
        } 
    }catch (error) {
            setMessage(error.response?.data?.message || 'Login failed');
        }
    };

    return (
        <div>
        <nav className='nav'>
        <a href="/AddUser">click to add your username </a>
        </nav>
        <div>
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                /><br />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                /><br />
                <button type="submit">Login</button>
            </form>
            <p>{message}</p>
        </div></div>
    );
}

export default LoginForm;



