import React from 'react'

export default function Testprops(props) {
  return (
    <div>
    <p>My name is:
    {props.name}, and iam <br />
    {props.age} , years old </p>
    <ol>
  {props.fruits.map((fruits,index)=>(
    <li key={index}>{fruits}</li>
  ))}
    </ol>


    </div>
  )
}
