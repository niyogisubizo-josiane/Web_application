import React from 'react'
import axios from 'axios'
import { useState } from 'react'
export default function App() {
  const[formdata,setFormData]=useState({
    name:'',
    email:'',
  })
  const handleSubmit=(e)=>{
    e.preventDefault()
    axios.post(`http://localhost:4000/insert`,formdata)
    .then(resp=>{
      console.log(resp)
    })
    .catch(err=>{
      console.log(err)
    })

  }


  return (
    <div>
      <h2>registeration form</h2>
      <form action="" method="post">
        <input type="text" placeholder='name'name='name' value={formdata.name} onChange={e=>setFormData({...formdata,name:e.target.value})} />
        <input type="text"  placeholder='email'name='email' value={formdata.email} onChange={e=>setFormData({...formdata,email:e.target.value})} />
        <button onClick={handleSubmit}>register</button>
      </form>
      
    </div>
  )
}
