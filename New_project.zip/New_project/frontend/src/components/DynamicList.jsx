import React from 'react'
import { useState } from 'react'
export default function DynamicList() {
    // create state variable
    const [input,setInput]=useState("")
    const [list,setList]=useState([])
    const Save=()=>{
        setList([...list,input])
        setInput("")
    }
  return (

    <div>
      
        <h1>Create your favorite food</h1>
        <input type="text" name='text' value={input} onChange={e=> setInput(e.target.value)} placeholder='enter food name'/>
        <button onClick={Save}>add your food</button>
        <ul>
            {
                list.map(data =>(
                    <li>{data}</li>
                ))
            }
        </ul>
      
    </div>
  )
}
