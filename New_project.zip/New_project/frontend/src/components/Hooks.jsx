import React from 'react'
import { useState } from 'react'
export default function Hooks() {
    const [count,setCount]= useState(0)
    const add=()=>{
        setCount(count+1)
    }

  return (
    <div>
<h1>count:{count}</h1>
<button onClick={add}>add</button>
    </div>
  )
}
